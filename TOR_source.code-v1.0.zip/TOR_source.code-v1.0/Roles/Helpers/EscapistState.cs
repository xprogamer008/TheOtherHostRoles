﻿namespace TownOfHost.RoleHelpers;

public enum EscapistState
{
    Default = 0,
    OnMark,
    OnRecall
}